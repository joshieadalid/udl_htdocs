"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from  myapp import views
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    #path('efectos_por_alcaldia/', views.efectos_por_alcaldia, name='efectos_por_alcaldia'),
    path('topicos_por_anio/', views.topicos_por_anio, name='topicos_por_anio'),
    path('topicos_por_municipio/', views.topicos_por_municipio, name='topicos_por_municipio'),
    path('tweets_por_tema/', views.tweets_por_tema, name='tweets_por_tema'),
    path('topicos_lineal_por_anio/', views.topicos_lineal_por_anio, name='topicos_lineal_por_anio'),
    path('efectos_por_municipio/', views.efectos_por_municipio, name='efectos_por_municipio'),
    path('tweets_por_efecto/', views.tweets_por_efecto, name='tweets_por_efecto'),
    
    #Barra de pastel cuántos tweets por tema en cada año (porcentaje)
    
    #topicos por año (comparacion de 3)
    #grafica de barras cantidad de tweets de cada topico por municipio
    #Mapa coroplético
    
] 

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
