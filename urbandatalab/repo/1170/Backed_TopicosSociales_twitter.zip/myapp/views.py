from email.headerregistry import DateHeader
from django.shortcuts import render
from django.http import JsonResponse
from .models import Contaminacion_vale_de_mexico, Tweet, Topicos, Fecha
from django.db.models import Count, Q
from django.core.serializers import serialize
from json import loads
from django.http import HttpResponse
from bertopic import BERTopic
import regex as re
import pandas as pd
from datetime import datetime
import os
from django.conf import settings
import plotly.graph_objects as go

topic_model = BERTopic.load("final2100_2")
df = pd.read_csv('entrenamiento_final2_2.csv')
tweets = df['tweet_tokenizado']
dias = df['dias'].tolist()
meses = df['meses']
años = df['años']

fechas = []

for i,_ in enumerate(años):
    fecha = str(años[i]) + "-" + str(meses[i]) + "-" + str(dias[i])
    #print(fecha)
    fechas.append(datetime.strptime(fecha,'%Y-%m-%d'))

topics_over_time = topic_model.topics_over_time(tweets, fechas, datetime_format="%b%M", nr_bins=25)

import plotly.offline as offline
    
def topicos(tema1, numero1_tema, tema2, numero2_tema, tema3, numero3_tema, fig_path):
    fig = topic_model.visualize_topics_over_time(topics_over_time, topics=[numero1_tema, numero2_tema, numero3_tema])
    
    fig.data[0].name = tema1  
    fig.data[1].name = tema2  
    fig.data[2].name = tema3 
    fig.update_layout(legend={'title': {'text': '<b>Temas</b>'}},
        title={
        'text': f'Comparación de los temas<br>{tema1}, {tema2} y {tema3}<br>a través del tiempo',
        'y':0.9,  # Ajusta la posición vertical del título
        'x':0.5,  # Ajusta la posición horizontal del título
        'xanchor': 'center',  # Alinea el título al centro horizontalmente
        'yanchor': 'top',      # Alinea el título a la parte superior verticalmente
        'font': dict(size=14)  # Ajusta el tamaño de la fuente del título
    }, xaxis_title='Tiempo', yaxis_title='Cantidad de tweets')

    offline.plot(fig, filename=fig_path, auto_open=False)


def topicos_por_anio(request):
    #tema = 'Efectos de la Contaminación en la Salud' 
    tema = request.GET.get('tema', '')

    print(tema)

    if tema:
        results = (Contaminacion_vale_de_mexico.objects
               .filter(temaID__tema=tema)
               .values('temaID__tema', 'fechaID__año')
               .annotate(total=Count('tweetID__tweet2'))
               .order_by('temaID__tema', 'fechaID__año'))
                           
        # Format the queryset into the desired JSON structure
        data = [{'anio': result['fechaID__año'], 'total': result['total']} for result in results]

    return JsonResponse(data, safe=False)

def topicos_por_municipio(request):
    tema = request.GET.get('tema', '')

    if tema:
        results = (Contaminacion_vale_de_mexico.objects
                   .filter(temaID__tema=tema)
               .values('temaID__tema', 'municipioID__municipio')
               .annotate(total=Count('tweetID__tweet2'))
               .order_by('temaID__tema', 'municipioID__municipio')[:20])
                           
        # Format the queryset into the desired JSON structure
        data = [{'municipio': result['municipioID__municipio'], 'total': result['total']} for result in results]

    return JsonResponse(data, safe=False)

def tweets_por_tema(request):
    tema = request.GET.get('tema', '')

    if tema:
        results = (Contaminacion_vale_de_mexico.objects
           .filter(temaID__tema=tema)
           .values('tweetID__tweet2'))
                           
        # Format the queryset into the desired JSON structure
        data = [{'tweet': result['tweetID__tweet2']} for result in results]

    return JsonResponse(data, safe=False)

def topicos_lineal_por_anio(request):
    tema1 = request.GET.get('tema1', '')
    tema2 = request.GET.get('tema2', '')
    tema3 = request.GET.get('tema3', '')
        
    df2 = pd.read_csv("temas.csv",encoding='latin-1')
    nombres = df2['nombres'].tolist()
    numeros = df2['numeros']

    nombre = tema1
    index = nombres.index(nombre)
    numero1_tema = numeros[index]
        
    nombre = tema2
    index = nombres.index(nombre)
    numero2_tema = numeros[index]
        
    nombre = tema3
    index = nombres.index(nombre)
    numero3_tema = numeros[index]
        
    figure_name = str(numero1_tema) + str(numero2_tema) + str(numero3_tema)

    fig_name = 'html\\' + figure_name + '.html'
    fig_path = os.path.join(settings.BASE_DIR, 'myproject', 'static', fig_name)
    
    if not os.path.isfile(fig_path):
        topicos(tema1, numero1_tema, tema2, numero2_tema, tema3, numero3_tema, fig_path)
        
    data = {'nombre': figure_name}
        
    return JsonResponse(data)

def efectos_por_municipio(request):
    efecto = request.GET.get('efecto', '')

    # Define the list of topics you want to filter by
    topics = [
        "Efectos de la Contaminación en la Salud",
        "Riesgos para la salud por la contaminación del aire",
        "Alergias Relacionadas con la Contaminación",
        "Impacto ambiental y enfermedades respiratorias"
    ]

    if efecto == 'todos':
        # Lista de efectos a buscar
        efectos = [
            'alergia', 'ojo', 'tos', 'dolor de cabeza', 'nariz',
            'gripa', 'picor', 'arden', 'pecho',
            'espalda', 'garganta', 'náusea', 'comezón', 'congestión nasal'
        ]
        
        # Construir la consulta usando Q objects
        query = Q(tweetID__tweet2__icontains=efectos[0])
        for efecto in efectos[1:]:
            query |= Q(tweetID__tweet2__icontains=efecto)
        
        # Ejecutar la consulta
        results = (Contaminacion_vale_de_mexico.objects
                    .filter(temaID__tema__in=topics)
                    .filter(query)
                    .values('municipioID__municipio')
                    .annotate(total=Count('municipioID__municipio'))
                    .order_by('municipioID__municipio'))
    else:
        results = (Contaminacion_vale_de_mexico.objects
                .filter(temaID__tema__in=topics, tweetID__tweet2__icontains=efecto)
                .values('municipioID__municipio')
                .annotate(total=Count('municipioID__municipio'))
                .order_by('municipioID__municipio'))
                           
        # Format the queryset into the desired JSON structure
    data = [{'municipio': result['municipioID__municipio'], 'total': result['total']} for result in results]

    return JsonResponse(data, safe=False)

def tweets_por_efecto(request):
    efecto = request.GET.get('efecto', '')

    if efecto:
        # Define the list of topics you want to filter by
        topics = [
            "Efectos de la Contaminación en la Salud",
            "Riesgos para la salud por la contaminación del aire",
            "Alergias Relacionadas con la Contaminación",
            "Impacto ambiental y enfermedades respiratorias"
        ]

        if efecto == 'todos':
            # Lista de efectos a buscar
            efectos = [
                'alergia', 'ojo', 'dolor', 'dolor de cabeza', 'nariz',
                'cabeza', 'pecho','garganta', 'náusea',
            ]
            
            # Construir la consulta usando Q objects
            query = Q(tweetID__tweet2__icontains=efectos[0])
            for e in efectos[1:]:
                query |= Q(tweetID__tweet2__icontains=e)
            
            # Ejecutar la consulta
            results = (Contaminacion_vale_de_mexico.objects
                        .filter(temaID__tema__in=topics)
                        .filter(query)
                        .values('tweetID__tweet2', 'municipioID__municipio'))
        else:
            results = (Contaminacion_vale_de_mexico.objects
                    .filter(temaID__tema__in=topics, tweetID__tweet2__icontains=efecto)
                    .values('tweetID__tweet2', 'municipioID__municipio'))
                               
        # Format the queryset into the desired JSON structure
        data = [{'tweet': result['tweetID__tweet2'], 'municipio': result['municipioID__municipio']} for result in results]

        return JsonResponse(data, safe=False)

    return JsonResponse([], safe=False)

