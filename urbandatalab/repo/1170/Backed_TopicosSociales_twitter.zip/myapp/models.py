from django.db import models
from django.http import JsonResponse

# myapp/models.py

class Municipio(models.Model):
    idMunicipio = models.AutoField(primary_key=True)
    municipio = models.CharField(max_length=255)
    estado = models.CharField(max_length=255)

    class Meta:
        db_table = 'municipio'
        app_label = 'myapp'

    def __str__(self):
        return self.municipio

class Coordenada(models.Model):
    idCoordenada = models.AutoField(primary_key=True)
    latitud = models.FloatField()
    longitud = models.FloatField()

    class Meta:
        app_label = 'myapp'
        db_table = 'coordenada'

    def __str__(self):
        return f"Coordenada ({self.latitud}, {self.longitud})"
    
class Fecha(models.Model):
    idfecha2 = models.AutoField(primary_key=True)
    dia = models.IntegerField()
    mes = models.IntegerField()
    año = models.IntegerField()
    fecha2 = models.DateField()

    class Meta:
        app_label = 'myapp'
        db_table = 'fecha2'

    def __str__(self):
        return f"Fecha ({self.fecha})"  
    
class Topicos(models.Model):
    idTopico = models.AutoField(primary_key=True)
    tema = models.CharField(max_length=255)

    class Meta:
        db_table = 'topicos'
        app_label = 'myapp'

    def __str__(self):
        return self.tema
    
class Tweet(models.Model):
    idTweet2 = models.AutoField(primary_key=True)
    tweet2 = models.CharField(max_length=255)
    url = models.CharField(max_length=255)

    class Meta:
        db_table = 'tweet2'
        app_label = 'myapp'

    def __str__(self):
        return self.url

class Contaminacion_vale_de_mexico(models.Model):
    idContaminacion = models.AutoField(primary_key=True)
    tweetID = models.ForeignKey(Tweet, on_delete=models.DO_NOTHING, db_column='tweetID')
    coordenadaID = models.ForeignKey(Coordenada, on_delete=models.DO_NOTHING, db_column='coordenadaID')
    fechaID = models.ForeignKey(Fecha, on_delete=models.DO_NOTHING, db_column='fechaID')
    municipioID = models.ForeignKey(Municipio, on_delete=models.CASCADE, db_column='municipioID')
    temaID = models.ForeignKey(Topicos, on_delete=models.CASCADE, db_column='temaID')
    # Add other fields as needed

    class Meta:
        app_label = 'myapp'
        db_table = 'contaminacion_valle_de_mexico'

    def __int__(self):
        return self.idContaminacion


# Create your models here.
